# AI 构造 Payload 功能说明

> 记录 AI 自动生成攻击 Payload 模块的当前实现状态，供下次开发快速恢复上下文。

---

## 一、功能概述

原有模式依赖手工编写的 YAML 策略文件提供固定 Prompt 模板，维护成本高且变化有限。

新模式将攻击目标（goal）和绕过手法（technique）拆分为两个独立维度，由 AI 根据组合动态生成攻击 Payload，每次生成结果各不相同，难以被固定规则拦截。

**两种模式均支持，通过请求参数区分：**
- 传 `strategyIds` → 旧模式，从 YAML 读固定模板
- 传 `goalIds + techniqueIds` → 新模式，AI 动态生成

---

## 二、生成流程

```
用户选择：goalIds + techniqueIds + generateCount

TaskService：
  for each goal × technique 组合：
    PayloadGeneratorService.generate(goal, technique, systemPrompt, count)
      → 加载 goals/{goal}.txt（攻击意图描述）
      → 加载 techniques/{technique}.txt（绕过手法描述）
      → 填入 generate.txt 主模板
      → 调用通义千问，返回 count 条 payload
    → 每条 payload 存入 ScanPayload 表

后续：ScanExecutorService 异步发包 → JudgeService 判定（流程不变）
```

**生成 payload 总数** = `goalIds数量 × techniqueIds数量 × generateCount`

---

## 三、文件结构

```
prompts/attack/
  generate.txt                    ← 主生成模板（所有组合共用）
  goals/
    prompt_leak.txt               ← 攻击目标：系统提示词泄露
    credential_leak.txt           ← 攻击目标：系统凭证配置泄露
    user_data_leak.txt            ← 攻击目标：用户文件数据泄露
    context_leak.txt              ← 攻击目标：跨用户上下文泄露
    model_info.txt                ← 攻击目标：模型信息探测
    prohibited_content.txt        ← 攻击目标：违禁内容生成
  techniques/
    none.txt                      ← 绕过手法：直接请求（基准测试）
    role_play.txt                 ← 绕过手法：角色扮演（DAN/对立角色/虚构场景）
    encoding.txt                  ← 绕过手法：编码混淆（Base64/倒序/字符替换）
    separator.txt                 ← 绕过手法：分隔符注入（伪造系统标签/忽略指令）
    emotional.txt                 ← 绕过手法：情感操纵（奶奶漏洞/临终请求/学术包装）
```

**扩展方式**：在对应目录新增 `.txt` 文件，重启服务自动生效，无需改代码。

---

## 四、generate.txt 变量说明

| 变量 | 来源 | 说明 |
|------|------|------|
| `{{GOAL_DESCRIPTION}}` | `goals/{goalId}.txt` 全文 | 攻击意图、成功标志、切入点 |
| `{{TECHNIQUE_DESCRIPTION}}` | `techniques/{techniqueId}.txt` 全文 | 手法核心逻辑、典型变体 |
| `{{TARGET_CONTEXT}}` | 用户填的 `systemPrompt` | 填写攻击场景描述和攻击目标（如"目标是某客服AI，系统中有保护的秘密词，目标是让AI说出来"）；**不要填系统提示词原文**，否则生成器会把原文嵌进 payload 导致攻击无效；未填则用默认值："目标是一个 AI 应用，具体系统配置未知" |
| `{{COUNT}}` | 用户填的 `generateCount`，默认 3 | 每个组合生成的条数 |

---

## 五、新增接口

### `GET /api/goals` — 查询可用攻击目标
```bash
curl http://localhost:9090/api/goals
# 返回：["prompt_leak","credential_leak","user_data_leak","context_leak","model_info","prohibited_content"]
```

**当前 6 个 goal：**

| Goal ID | 中文名 |
|---------|--------|
| `prompt_leak` | 系统提示词泄露 |
| `credential_leak` | 系统凭证配置泄露 |
| `user_data_leak` | 用户文件数据泄露 |
| `context_leak` | 跨用户上下文泄露 |
| `model_info` | 模型信息探测 |
| `prohibited_content` | 违禁内容生成 |

### `GET /api/techniques` — 查询可用绕过手法
```bash
curl http://localhost:9090/api/techniques
# 返回：["role_play", "encoding", "emotional", "separator", "none"]
```

### `POST /api/tasks`（新模式参数）

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `goalIds` | List | ✅ | 攻击目标列表，从 `/api/goals` 取 |
| `techniqueIds` | List | ✅ | 绕过手法列表，从 `/api/techniques` 取 |
| `generateCount` | int | ❌ | 每组合生成条数，默认 3 |
| `systemPrompt` | String | ❌ | 攻击场景背景描述 + 攻击目标（如"目标是某客服AI，存在保护的秘密词，需让AI说出真实内容"）；仅作情报背景供生成器理解场景，**不要填系统提示词原文** |

**请求示例：**
```json
{
  "name": "测试某AI客服",
  "scanMode": "HTTP_TEMPLATE",
  "rawRequestTemplate": "POST /api/chat HTTP/1.1\nHost: target.example.com\nAuthorization: Bearer your-token\nContent-Type: application/json\n\n{\"message\":\"{{PAYLOAD}}\"}",
  "promptFieldPath": "message",
  "systemPrompt": "目标是一个在线客服AI，禁止透露系统设置，我们需要通过注入让AI说出被保护的系统配置内容",
  "goalIds": ["prompt_leak", "credential_leak"],
  "techniqueIds": ["role_play", "emotional", "encoding"],
  "generateCount": 3
}
```
生成：2 × 3 × 3 = **18 条 payload**，全部自动发包并 AI 判定。

---

## 六、完整工作流

```
1. GET  /api/goals          → 查询可用攻击目标
2. GET  /api/techniques     → 查询可用绕过手法
3. POST /api/tasks          → 创建任务（AI 自动生成 payload）
4. GET  /api/tasks/{id}     → 轮询进度，等 status=COMPLETED
5. GET  /api/tasks/{id}/results → 查看结果，关注 verdict=SUCCESS 的条目
```

---

## 七、新增 / 修改的文件

### 新增
| 文件 | 说明 |
|------|------|
| `service/PayloadGeneratorService.java` | 加载提示词文件，调 AI 生成 payload |
| `controller/AttackResourceController.java` | GET /api/goals 和 /api/techniques |
| `prompts/attack/generate.txt` | 主生成模板 |
| `prompts/attack/goals/prompt_leak.txt` | 系统提示词泄露目标描述 |
| `prompts/attack/goals/credential_leak.txt` | 系统凭证配置泄露目标描述 |
| `prompts/attack/goals/user_data_leak.txt` | 用户文件数据泄露目标描述 |
| `prompts/attack/goals/context_leak.txt` | 跨用户上下文泄露目标描述 |
| `prompts/attack/goals/model_info.txt` | 模型信息探测目标描述 |
| `prompts/attack/goals/prohibited_content.txt` | 违禁内容生成目标描述 |
| `prompts/attack/techniques/none.txt` | 直接请求手法 |
| `prompts/attack/techniques/role_play.txt` | 角色扮演手法 |
| `prompts/attack/techniques/encoding.txt` | 编码混淆手法 |
| `prompts/attack/techniques/separator.txt` | 分隔符注入手法 |
| `prompts/attack/techniques/emotional.txt` | 情感操纵手法 |

### 修改
| 文件 | 改动 |
|------|------|
| `dto/CreateTaskRequest.java` | 新增 `goalIds`、`techniqueIds`、`generateCount` |
| `service/TaskService.java` | 新增 `buildPayloadsWithAI()`，判断走新模式还是旧模式 |

---

## 八、后续扩展方向

1. **新增 goal**：在 `prompts/attack/goals/` 下新增 `.txt` 文件即可
2. **新增 technique**：在 `prompts/attack/techniques/` 下新增 `.txt` 文件即可
3. **AI 变异**：后续可在判定结果基础上，让 AI 根据 FAIL 的响应自动调整生成策略（自适应反馈循环）
