package com.promptfuzzer.controller;

import com.promptfuzzer.service.StrategyService;
import com.promptfuzzer.strategy.Strategy;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
@RequestMapping("/api/strategies")
@RequiredArgsConstructor
public class StrategyController {

    private final StrategyService strategyService;

    @GetMapping
    public ResponseEntity<Collection<Strategy>> listStrategies() {
        return ResponseEntity.ok(strategyService.listAll());
    }
}
