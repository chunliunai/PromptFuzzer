package com.promptfuzzer.service;

import com.promptfuzzer.dto.CreateTaskRequest;
import com.promptfuzzer.dto.PageResponse;
import com.promptfuzzer.dto.ScanResultResponse;
import com.promptfuzzer.dto.TaskResponse;
import com.promptfuzzer.entity.ScanPayload;
import com.promptfuzzer.entity.ScanResult;
import com.promptfuzzer.entity.Task;
import com.promptfuzzer.repository.ScanPayloadRepository;
import com.promptfuzzer.repository.ScanResultRepository;
import com.promptfuzzer.repository.TaskRepository;
import com.promptfuzzer.strategy.Strategy;
import com.promptfuzzer.strategy.StrategyRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;
    private final ScanPayloadRepository scanPayloadRepository;
    private final ScanResultRepository scanResultRepository;
    private final StrategyRegistry strategyRegistry;
    private final ScanExecutorService scanExecutorService;
    private final PayloadGeneratorService payloadGeneratorService;

    public TaskResponse createTask(CreateTaskRequest request) {
        Task task = new Task();
        task.setName(request.getName());
        task.setScanMode(Task.ScanMode.valueOf(request.getScanMode()));
        task.setRawRequestTemplate(request.getRawRequestTemplate());
        task.setPromptFieldPath(request.getPromptFieldPath());
        task.setAttackContext(request.getAttackContext());
        if (request.getStrategyIds() != null && !request.getStrategyIds().isEmpty()) {
            task.setStrategyIds(String.join(",", request.getStrategyIds()));
        }
        task.setStatus(Task.TaskStatus.PENDING);
        task = taskRepository.save(task);

        List<ScanPayload> payloads;
        boolean useGenerator = request.getGoalIds() != null && !request.getGoalIds().isEmpty()
                && request.getTechniqueIds() != null && !request.getTechniqueIds().isEmpty();

        if (useGenerator) {
            payloads = buildPayloadsWithAI(task, request);
        } else {
            payloads = buildPayloads(task, request.getStrategyIds());
        }
        scanPayloadRepository.saveAll(payloads);

        task.setTotalCount(payloads.size());
        taskRepository.save(task);

        final Long taskId = task.getId();
        new Thread(() -> {
            try { Thread.sleep(500); } catch (InterruptedException ignored) {}
            scanExecutorService.executeTask(taskId);
        }).start();

        return TaskResponse.from(task);
    }

    private List<ScanPayload> buildPayloadsWithAI(Task task, CreateTaskRequest request) {
        List<ScanPayload> payloads = new ArrayList<>();
        for (String goalId : request.getGoalIds()) {
            for (String techniqueId : request.getTechniqueIds()) {
                List<String> generated = payloadGeneratorService.generate(
                        goalId, techniqueId, request.getAttackContext(), request.getGenerateCount());

                if (generated.isEmpty()) {
                    log.warn("No payloads generated for goal={} technique={}", goalId, techniqueId);
                    continue;
                }

                for (int i = 0; i < generated.size(); i++) {
                    ScanPayload payload = new ScanPayload();
                    payload.setTaskId(task.getId());
                    payload.setStrategyId("ai_generated");
                    payload.setGoal(goalId);
                    payload.setTechnique(techniqueId);
                    payload.setTemplateName(goalId + "_" + techniqueId + "_" + (i + 1));
                    payload.setContent(generated.get(i));
                    payload.setStatus(ScanPayload.PayloadStatus.PENDING);
                    payloads.add(payload);
                }
                log.info("Generated {} payloads for goal={} technique={}", generated.size(), goalId, techniqueId);
            }
        }
        return payloads;
    }

    private List<ScanPayload> buildPayloads(Task task, List<String> strategyIds) {
        List<ScanPayload> payloads = new ArrayList<>();
        List<Strategy> strategies = strategyRegistry.getByIds(strategyIds);

        for (Strategy strategy : strategies) {
            if (strategy.getTemplates() == null) continue;
            for (Strategy.PayloadTemplate template : strategy.getTemplates()) {
                ScanPayload payload = new ScanPayload();
                payload.setTaskId(task.getId());
                payload.setStrategyId(strategy.getId());
                payload.setGoal(strategy.getGoal());
                payload.setTechnique(strategy.getTechnique());
                payload.setTemplateName(template.getName());
                payload.setContent(template.getPrompt());
                payload.setStatus(ScanPayload.PayloadStatus.PENDING);
                payloads.add(payload);
            }
        }
        return payloads;
    }

    public List<TaskResponse> listTasks() {
        return taskRepository.findAll().stream()
                .map(TaskResponse::from)
                .collect(Collectors.toList());
    }

    public TaskResponse getTask(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found: " + id));
        return TaskResponse.from(task);
    }

    public PageResponse<ScanResultResponse> getTaskResults(Long taskId, int page, int size) {
        Page<ScanResult> resultPage = scanResultRepository.findByTaskId(taskId, PageRequest.of(page, size));
        List<Long> payloadIds = resultPage.getContent().stream()
                .map(ScanResult::getPayloadId).collect(Collectors.toList());
        List<ScanPayload> payloads = scanPayloadRepository.findAllById(payloadIds);

        List<ScanResultResponse> items = resultPage.getContent().stream().map(result -> {
            ScanPayload payload = payloads.stream()
                    .filter(p -> p.getId().equals(result.getPayloadId()))
                    .findFirst().orElse(null);
            return ScanResultResponse.from(result, payload);
        }).collect(Collectors.toList());

        return PageResponse.of(resultPage.getTotalElements(), page, size, items);
    }

    @Transactional
    public void deleteTask(Long id) {
        taskRepository.deleteById(id);
    }
}
