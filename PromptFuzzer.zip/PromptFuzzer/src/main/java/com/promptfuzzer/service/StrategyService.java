package com.promptfuzzer.service;

import com.promptfuzzer.strategy.Strategy;
import com.promptfuzzer.strategy.StrategyRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
@RequiredArgsConstructor
public class StrategyService {

    private final StrategyRegistry strategyRegistry;

    public Collection<Strategy> listAll() {
        return strategyRegistry.getAll().values();
    }
}
