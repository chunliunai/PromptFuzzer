package com.promptfuzzer.strategy;

import lombok.Data;

import java.util.List;

@Data
public class Strategy {

    private String id;
    private String goal;
    private String technique;
    private String name;
    private String severity;
    private List<PayloadTemplate> templates;

    @Data
    public static class PayloadTemplate {
        private String name;
        private String prompt;
    }
}
