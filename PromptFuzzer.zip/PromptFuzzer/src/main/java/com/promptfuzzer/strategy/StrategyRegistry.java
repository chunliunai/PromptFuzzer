package com.promptfuzzer.strategy;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import jakarta.annotation.PostConstruct;
import java.io.InputStream;
import java.util.*;

@Slf4j
@Component
public class StrategyRegistry {

    private final Map<String, Strategy> strategies = new LinkedHashMap<>();

    @PostConstruct
    public void load() {
        try {
            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
            Resource[] resources = resolver.getResources("classpath:strategies/*.yml");
            Yaml yaml = new Yaml(new Constructor(Strategy.class, new LoaderOptions()));

            for (Resource resource : resources) {
                try (InputStream is = resource.getInputStream()) {
                    Strategy strategy = yaml.load(is);
                    if (strategy != null && strategy.getId() != null) {
                        strategies.put(strategy.getId(), strategy);
                        log.info("Loaded strategy: {}", strategy.getId());
                    }
                } catch (Exception e) {
                    log.error("Failed to load strategy file: {}", resource.getFilename(), e);
                }
            }
            log.info("Total strategies loaded: {}", strategies.size());
        } catch (Exception e) {
            log.error("Failed to load strategies", e);
        }
    }

    public Map<String, Strategy> getAll() {
        return Collections.unmodifiableMap(strategies);
    }

    public Optional<Strategy> getById(String id) {
        return Optional.ofNullable(strategies.get(id));
    }

    public List<Strategy> getByIds(List<String> ids) {
        List<Strategy> result = new ArrayList<>();
        for (String id : ids) {
            Optional<Strategy> s = getById(id);
            s.ifPresent(result::add);
        }
        return result;
    }
}
