package com.promptfuzzer.dto;

import lombok.Data;

import java.util.List;

@Data
public class CreateTaskRequest {

    private String name;
    private String scanMode = "HTTP_TEMPLATE";
    private String rawRequestTemplate;
    private String promptFieldPath;
    private String attackContext;

    private List<String> strategyIds;

    private List<String> goalIds;
    private List<String> techniqueIds;
    private int generateCount = 3;
}
