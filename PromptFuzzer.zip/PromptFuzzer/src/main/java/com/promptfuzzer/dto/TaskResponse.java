package com.promptfuzzer.dto;

import com.promptfuzzer.entity.Task;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TaskResponse {

    private Long id;
    private String name;
    private String scanMode;
    private String status;
    private int totalCount;
    private int successCount;
    private int failCount;
    private int uncertainCount;
    private String reportSummary;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static TaskResponse from(Task task) {
        TaskResponse r = new TaskResponse();
        r.setId(task.getId());
        r.setName(task.getName());
        r.setScanMode(task.getScanMode().name());
        r.setStatus(task.getStatus().name());
        r.setTotalCount(task.getTotalCount());
        r.setSuccessCount(task.getSuccessCount());
        r.setFailCount(task.getFailCount());
        r.setUncertainCount(task.getUncertainCount());
        r.setReportSummary(task.getReportSummary());
        r.setCreatedAt(task.getCreatedAt());
        r.setUpdatedAt(task.getUpdatedAt());
        return r;
    }
}
